package de.watchlist.aktien

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.launch

private val Blue = Color(0xFF2457D6)
private val Bg = Color(0xFFF5F6F8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { WatchlistScreen() }
    }
}

@Composable
fun WatchlistScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var stocks by remember { mutableStateOf(WatchlistStore.load(context)) }
    var selectedTicker by remember { mutableStateOf(stocks.firstOrNull()?.ticker) }
    var filter by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    val selected = stocks.firstOrNull { it.ticker == selectedTicker }

    // Speichert dauerhaft und aktualisiert das Widget
    fun persist(newList: List<Stock>) {
        stocks = newList
        WatchlistStore.save(context, newList)
        scope.launch { WatchlistWidget().updateAll(context) }
    }

    val shown = stocks.filter {
        filter.isBlank() || it.name.contains(filter, true) || it.ticker.contains(filter, true)
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Bg)) {
        Scaffold(containerColor = Bg) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(12.dp))
                Text("Meine Watchlist", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "${stocks.size} Unternehmen · ${stocks.map { it.sector }.distinct().size} Branchen",
                    color = Color.Gray
                )
                Spacer(Modifier.height(12.dp))
                DetailCard(selected) { s ->
                    persist(stocks.filter { it.ticker != s.ticker })
                    selectedTicker = null
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = filter, onValueChange = { filter = it },
                    label = { Text("Liste durchsuchen") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    shown.groupBy { it.sector }.forEach { (sector, list) ->
                        item(key = "h_$sector") {
                            Text(
                                sector, style = MaterialTheme.typography.labelLarge,
                                color = Blue, modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                        items(list, key = { it.ticker }) { stock ->
                            StockRow(stock, stock.ticker == selectedTicker) { selectedTicker = stock.ticker }
                        }
                    }
                }
                Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                    Text("＋ Aktie hinzufügen")
                }
            }
            if (adding) AddStockDialog(
                existing = stocks,
                onAdd = { s -> persist(stocks + s); selectedTicker = s.ticker; adding = false },
                onDismiss = { adding = false }
            )
        }
    }
}

@Composable
fun DetailCard(stock: Stock?, onRemove: (Stock) -> Unit) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            if (stock == null) {
                Text("Keine Aktie ausgewählt", color = Color.Gray)
                return@Column
            }
            Text(stock.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("${stock.ticker}  ·  ${stock.sector}", color = Color.Gray)
            Spacer(Modifier.height(12.dp))
            // Bewusst kein Fantasie-Diagramm: Es gibt noch keine echten Kursdaten.
            Box(
                Modifier.fillMaxWidth().height(90.dp)
                    .border(1.dp, Color(0xFFD0D5DD), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Kursdiagramm folgt, sobald ein Kursdatenanbieter angebunden ist.",
                    color = Color(0xFF667085), modifier = Modifier.padding(12.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("1T", "1M", "1J", "Seit Datum").forEach { label ->
                    AssistChip(onClick = { }, enabled = false, label = { Text(label) })
                }
            }
            TextButton(onClick = { onRemove(stock) }) { Text("Aus Liste entfernen") }
        }
    }
}

@Composable
fun StockRow(stock: Stock, isSelected: Boolean, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFFE8EEFF) else Color.White)
    ) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stock.name, fontWeight = FontWeight.SemiBold)
                Text(stock.ticker, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            if (isSelected) Text("Ausgewählt", color = Blue, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
fun AddStockDialog(existing: List<Stock>, onAdd: (Stock) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var ticker by remember { mutableStateOf("") }
    var sector by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    fun clean(s: String) = s.replace("|", " ").replace("\n", " ").trim()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Aktie hinzufügen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name (z. B. SAP)") }, singleLine = true)
                OutlinedTextField(ticker, { ticker = it }, label = { Text("Börsenkürzel (z. B. SAP.DE)") }, singleLine = true)
                OutlinedTextField(sector, { sector = it }, label = { Text("Branche (optional)") }, singleLine = true)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val n = clean(name)
                val t = clean(ticker).uppercase()
                val b = clean(sector).ifBlank { "Eigene Auswahl" }
                when {
                    n.isEmpty() || t.isEmpty() -> error = "Bitte Name und Börsenkürzel eintragen."
                    existing.any { it.ticker == t } -> error = "Dieses Kürzel ist schon in der Liste."
                    else -> onAdd(Stock(n, t, b))
                }
            }) { Text("Hinzufügen") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}
