package de.watchlist.aktien

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

private val DeepBg = Color(0xFF050B14)
private val CardBg = Color(0xFF0D1B2E)
private val AccentBlue = Color(0xFF00B0FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { WatchlistAppScreen() }
    }
}

@Composable
fun WatchlistAppScreen() {
    val context = LocalContext.current
    var stocks by remember { mutableStateOf(WatchlistStore.load(context)) }
    var activeIndex by remember { mutableIntStateOf(WatchlistStore.getCurrentIndex(context, stocks.size)) }
    var showAddDialog by remember { mutableStateOf(false) }
    var previewBitmap by remember { mutableStateOf(WatchlistStore.renderArcWidgetBitmap(context)) }

    fun syncAll(newList: List<Stock>, newIndex: Int = activeIndex) {
        val safeList = if (newList.isEmpty()) initialStocks else newList
        stocks = safeList
        val clampedIdx = newIndex.mod(safeList.size)
        activeIndex = clampedIdx
        WatchlistStore.save(context, safeList)
        WatchlistStore.setCurrentIndex(context, clampedIdx)
        previewBitmap = WatchlistStore.renderArcWidgetBitmap(context)
        WatchlistWidgetReceiver.updateAllWidgets(context)
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = AccentBlue,
            background = DeepBg,
            surface = CardBg
        )
    ) {
        Scaffold(containerColor = DeepBg) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "Aktien-Bogen & Watchlist",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "${stocks.size} Aktien in der Watchlist (werden im Widget getauscht)",
                    color = Color(0xFF8AB4F8),
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))

                // Live-Vorschau des blauen Aktien-Bogens + Tauschen-Button
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            bitmap = previewBitmap.asImageBitmap(),
                            contentDescription = "Vorschau Aktien-Bogen",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(210.dp)
                                .clickable {
                                    WatchlistStore.nextStock(context)
                                    activeIndex = WatchlistStore.getCurrentIndex(context, stocks.size)
                                    previewBitmap = WatchlistStore.renderArcWidgetBitmap(context)
                                    WatchlistWidgetReceiver.updateAllWidgets(context)
                                }
                        )
                        Spacer(Modifier.height(6.dp))
                        Button(
                            onClick = {
                                WatchlistStore.nextStock(context)
                                activeIndex = WatchlistStore.getCurrentIndex(context, stocks.size)
                                previewBitmap = WatchlistStore.renderArcWidgetBitmap(context)
                                WatchlistWidgetReceiver.updateAllWidgets(context)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0066CC)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("⟳ Nächste Aktie im Bogen zeigen", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Deine Watchlist",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Button(
                        onClick = { showAddDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                    ) {
                        Text("＋ Aktie hinzufügen", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(stocks, key = { idx, s -> "${s.ticker}_$idx" }) { index, stock ->
                        val isCurrent = index == activeIndex
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isCurrent) Color(0xFF14355B) else CardBg
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { syncAll(stocks, index) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "${index + 1}. ${stock.name} (${stock.ticker})",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    val sign = if (stock.changePct >= 0) "+" else ""
                                    Text(
                                        String.format(
                                            Locale.US,
                                            "%.2f USD (%s%.2f%%) · %s",
                                            stock.basePrice,
                                            sign,
                                            stock.changePct,
                                            stock.sector
                                        ),
                                        color = Color(0xFF8AB4F8),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                if (stocks.size > 1) {
                                    TextButton(
                                        onClick = {
                                            val updated = stocks.toMutableList().also { it.removeAt(index) }
                                            syncAll(updated, 0)
                                        }
                                    ) {
                                        Text("Entfernen", color = Color(0xFFFF6B6B))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (showAddDialog) {
                AddStockToWatchlistDialog(
                    onAdd = { newStock ->
                        val updated = stocks + newStock
                        syncAll(updated, updated.lastIndex)
                        showAddDialog = false
                    },
                    onDismiss = { showAddDialog = false }
                )
            }
        }
    }
}

@Composable
fun AddStockToWatchlistDialog(onAdd: (Stock) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var ticker by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("195.00") }
    var changeText by remember { mutableStateOf("2.10") }
    var sector by remember { mutableStateOf("Technologie") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Aktie zur Watchlist hinzufügen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name (z. B. Apple)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = ticker,
                    onValueChange = { ticker = it },
                    label = { Text("Kürzel (z. B. AAPL)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Kurs in USD (z. B. 228.50)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = changeText,
                    onValueChange = { changeText = it },
                    label = { Text("Tagesänderung % (z. B. 1.85)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = sector,
                    onValueChange = { sector = it },
                    label = { Text("Branche") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val cleanName = name.replace("|", "").trim().ifEmpty { "Neue Aktie" }
                    val cleanTicker = ticker.replace("|", "").trim().uppercase().ifEmpty { "NEW" }
                    val cleanSector = sector.replace("|", "").trim().ifEmpty { "Watchlist" }
                    val price = priceText.replace(",", ".").toDoubleOrNull() ?: 150.0
                    val change = changeText.replace(",", ".").toDoubleOrNull() ?: 1.5
                    onAdd(Stock(cleanName, cleanTicker, cleanSector, price, change))
                }
            ) {
                Text("Hinzufügen")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Abbrechen")
            }
        }
    )
}
