package de.watchlist.aktien

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val DarkBg = Color(0xFF1F1F1F)
private val CardGray = Color(0xFF333333)
private val AccentGreen = Color(0xFF57B869)
private val AccentRed = Color(0xFFE0533C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { WatchlistApp() }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WatchlistApp() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var stocks by remember { mutableStateOf(WatchlistStore.load(context)) }
    var currentTf by remember { mutableStateOf(WatchlistStore.getTimeframe(context)) }
    var customDate by remember { mutableStateOf(WatchlistStore.getCustomDateLabel(context)) }
    var widgetPreview by remember { mutableStateOf(WatchlistStore.renderWidgetBitmap(context)) }
    var isRefreshing by remember { mutableStateOf(false) }

    var showAddDialog by remember { mutableStateOf(false) }
    var showDateDialog by remember { mutableStateOf(false) }
    var longPressedStockIndex by remember { mutableStateOf<Int?>(null) }

    var draggingIndex by remember { mutableStateOf<Int?>(null) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }

    fun refreshRealData() {
        coroutineScope.launch {
            isRefreshing = true
            WatchlistStore.fetchRealStockData(context)
            stocks = WatchlistStore.load(context)
            widgetPreview = WatchlistStore.renderWidgetBitmap(context)
            WatchlistWidgetReceiver.updateAllWidgets(context)
            isRefreshing = false
        }
    }

    // Beim Start einmal echte Kurse von Yahoo Finance laden
    LaunchedEffect(Unit) {
        refreshRealData()
    }

    fun persistAll(newList: List<Stock> = stocks, newTf: Timeframe = currentTf) {
        val safe = if (newList.isEmpty()) initialStocks else newList
        stocks = safe
        currentTf = newTf
        WatchlistStore.save(context, safe)
        WatchlistStore.setTimeframe(context, newTf)
        widgetPreview = WatchlistStore.renderWidgetBitmap(context)
        WatchlistWidgetReceiver.updateAllWidgets(context)
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color.White,
            background = DarkBg,
            surface = CardGray
        )
    ) {
        Scaffold(containerColor = DarkBg) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Aktien-Watchlist",
                                color = Color.White,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (isRefreshing) {
                                Spacer(Modifier.width(8.dp))
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            }
                        }
                        Text(
                            text = "Live-Daten via Yahoo Finance · Halten zum Sortieren",
                            color = Color(0xFFAAAAAA),
                            fontSize = 12.sp
                        )
                    }
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF4A4A4A),
                        modifier = Modifier
                            .size(46.dp)
                            .combinedClickable(onClick = { showAddDialog = true })
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("+", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))

                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2B2B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            bitmap = widgetPreview.asImageBitmap(),
                            contentDescription = "Widget-Vorschau",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(250.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Timeframe.entries.forEach { tf ->
                                val label = if (tf == Timeframe.DATE) customDate else tf.label
                                FilterChip(
                                    selected = (currentTf == tf),
                                    onClick = {
                                        if (tf == Timeframe.DATE) {
                                            showDateDialog = true
                                        }
                                        persistAll(stocks, tf)
                                    },
                                    label = { Text(label) }
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(stocks, key = { _, item -> item.ticker }) { index, stock ->
                        val pct = stock.changeFor(currentTf)
                        val isPos = pct >= 0
                        val isDragging = (draggingIndex == index)

                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    isDragging -> Color(0xFF505050)
                                    index == 0 -> Color(0xFF3E3E3E)
                                    else -> CardGray
                                }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .graphicsLayer {
                                    translationY = if (isDragging) dragOffsetY else 0f
                                }
                                .combinedClickable(
                                    onClick = {
                                        val mutable = stocks.toMutableList()
                                        val item = mutable.removeAt(index)
                                        mutable.add(0, item)
                                        persistAll(mutable)
                                    },
                                    onLongClick = {
                                        longPressedStockIndex = index
                                    }
                                )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .padding(end = 14.dp)
                                        .pointerInput(stocks.size) {
                                            detectDragGesturesAfterLongPress(
                                                onDragStart = {
                                                    draggingIndex = index
                                                    dragOffsetY = 0f
                                                },
                                                onDragCancel = {
                                                    draggingIndex = null
                                                    dragOffsetY = 0f
                                                },
                                                onDragEnd = {
                                                    draggingIndex = null
                                                    dragOffsetY = 0f
                                                },
                                                onDrag = { change, dragAmount ->
                                                    change.consume()
                                                    dragOffsetY += dragAmount.y
                                                    val currentIdx = draggingIndex ?: return@detectDragGesturesAfterLongPress
                                                    val threshold = 110f
                                                    if (dragOffsetY > threshold && currentIdx < stocks.lastIndex) {
                                                        val m = stocks.toMutableList()
                                                        val moved = m.removeAt(currentIdx)
                                                        m.add(currentIdx + 1, moved)
                                                        draggingIndex = currentIdx + 1
                                                        dragOffsetY = 0f
                                                        persistAll(m)
                                                    } else if (dragOffsetY < -threshold && currentIdx > 0) {
                                                        val m = stocks.toMutableList()
                                                        val moved = m.removeAt(currentIdx)
                                                        m.add(currentIdx - 1, moved)
                                                        draggingIndex = currentIdx - 1
                                                        dragOffsetY = 0f
                                                        persistAll(m)
                                                    }
                                                }
                                            )
                                        }
                                ) {
                                    Text("≡", color = Color(0xFFBBBBBB), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = stock.ticker,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            text = stock.name,
                                            color = Color(0xFFCCCCCC),
                                            fontSize = 14.sp
                                        )
                                    }
                                    val roleText = when (index) {
                                        0 -> "Oben im Widget-Chart"
                                        1, 2 -> "Im Widget sichtbar (Zeile $index)"
                                        else -> "In Watchlist (Position ${index + 1})"
                                    }
                                    Text(roleText, color = Color(0xFF999999), fontSize = 12.sp)
                                }

                                val sign = if (isPos) "+" else "-"
                                Text(
                                    text = String.format(
                                        Locale.US,
                                        "%s%.1f%%   %.0f$",
                                        sign,
                                        kotlin.math.abs(pct),
                                        stock.basePrice
                                    ),
                                    color = if (isPos) AccentGreen else AccentRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )

                                Spacer(Modifier.width(8.dp))

                                Column {
                                    Text(
                                        text = "▲",
                                        color = if (index > 0) Color.White else Color(0xFF555555),
                                        fontSize = 14.sp,
                                        modifier = Modifier
                                            .padding(2.dp)
                                            .combinedClickable(onClick = {
                                                if (index > 0) {
                                                    val m = stocks.toMutableList()
                                                    val item = m.removeAt(index)
                                                    m.add(index - 1, item)
                                                    persistAll(m)
                                                }
                                            })
                                    )
                                    Text(
                                        text = "▼",
                                        color = if (index < stocks.lastIndex) Color.White else Color(0xFF555555),
                                        fontSize = 14.sp,
                                        modifier = Modifier
                                            .padding(2.dp)
                                            .combinedClickable(onClick = {
                                                if (index < stocks.lastIndex) {
                                                    val m = stocks.toMutableList()
                                                    val item = m.removeAt(index)
                                                    m.add(index + 1, item)
                                                    persistAll(m)
                                                }
                                            })
                                    )
                                }
                            }
                        }
                    }
                }
            }

            longPressedStockIndex?.let { idx ->
                val target = stocks.getOrNull(idx)
                if (target != null) {
                    AlertDialog(
                        onDismissRequest = { longPressedStockIndex = null },
                        title = { Text("${target.name} (${target.ticker})") },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Was möchtest du mit dieser Aktie machen?")
                                if (idx > 0) {
                                    TextButton(
                                        onClick = {
                                            val m = stocks.toMutableList()
                                            val item = m.removeAt(idx)
                                            m.add(0, item)
                                            persistAll(m)
                                            longPressedStockIndex = null
                                        }
                                    ) {
                                        Text("↑ Nach ganz oben (in die Widget-Grafik)")
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    if (stocks.size > 1) {
                                        val m = stocks.toMutableList().also { it.removeAt(idx) }
                                        persistAll(m)
                                    }
                                    longPressedStockIndex = null
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = AccentRed)
                            ) {
                                Text("Löschen", color = Color.White)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { longPressedStockIndex = null }) {
                                Text("Abbrechen")
                            }
                        }
                    )
                }
            }

            if (showAddDialog) {
                AddStockDialog(
                    onAdd = { newStock ->
                        persistAll(listOf(newStock) + stocks)
                        refreshRealData()
                        showAddDialog = false
                    },
                    onDismiss = { showAddDialog = false }
                )
            }

            if (showDateDialog) {
                var dateInput by remember { mutableStateOf(customDate) }
                AlertDialog(
                    onDismissRequest = { showDateDialog = false },
                    title = { Text("Zeitraum-Datum festlegen") },
                    text = {
                        OutlinedTextField(
                            value = dateInput,
                            onValueChange = { dateInput = it },
                            label = { Text("z. B. 01.01.25 oder (Datum)") },
                            singleLine = true
                        )
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            customDate = dateInput.ifBlank { "(Datum)" }
                            WatchlistStore.setCustomDateLabel(context, customDate)
                            persistAll(stocks, Timeframe.DATE)
                            showDateDialog = false
                        }) {
                            Text("Speichern")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDateDialog = false }) {
                            Text("Abbrechen")
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun AddStockDialog(onAdd: (Stock) -> Unit, onDismiss: () -> Unit) {
    var ticker by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Neue Aktie hinzufügen (+)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = ticker,
                    onValueChange = { ticker = it },
                    label = { Text("Yahoo-Ticker (z. B. AAPL, TSLA, 005380.KS)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Unternehmensname (z. B. Apple)") },
                    singleLine = true
                )
                Text(
                    "Die echten Kursdaten und Kerzen werden automatisch von Yahoo Finance geladen.",
                    color = Color(0xFFAAAAAA),
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cleanTicker = ticker.replace("|", "").trim().uppercase().ifEmpty { "AAPL" }
                val cleanName = name.replace("|", "").trim().ifEmpty { cleanTicker }
                onAdd(Stock(cleanName, cleanTicker, "Watchlist", 150.0, 1.5))
            }) {
                Text("Hinzufügen")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Abbrechen")
            }
        }
    )
}
