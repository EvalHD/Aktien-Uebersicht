package de.watchlist.aktien

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

data class Stock(
    val name: String,
    val ticker: String,
    val sector: String,
    val basePrice: Double = 192.40,
    val changePct: Double = 2.35
) {
    // Erzeugt realistische Intraday-Kerzen (Open, High, Low, Close) für den Aktien-Bogen
    fun generateCandles(count: Int = 64): List<Candle> {
        val seed = ticker.fold(0) { acc, c -> acc * 31 + c.code }
        val list = mutableListOf<Candle>()
        var current = basePrice * (1.0 - (changePct / 200.0))
        val volatility = basePrice * 0.0045

        for (i in 0 until count) {
            val wave1 = sin(i * 0.24 + (seed % 17)) * volatility * 1.4
            val wave2 = cos(i * 0.53 + (seed % 31)) * volatility * 0.9
            val trend = (basePrice * (changePct / 100.0)) / count
            val open = current
            val close = open + wave1 * 0.35 + wave2 * 0.25 + trend
            val high = maxOf(open, close) + abs(sin(i * 0.9 + seed)) * volatility * 1.2
            val low = minOf(open, close) - abs(cos(i * 0.7 + seed)) * volatility * 1.2
            list.add(Candle(open.toFloat(), high.toFloat(), low.toFloat(), close.toFloat()))
            current = close
        }
        return list
    }
}

data class Candle(val open: Float, val high: Float, val low: Float, val close: Float)

val initialStocks = listOf(
    Stock("NVIDIA", "NVDA", "KI und Prozessoren", 192.40, 2.84),
    Stock("AMD", "AMD", "KI und Prozessoren", 156.80, 1.45),
    Stock("Broadcom", "AVGO", "KI und Prozessoren", 178.20, 3.12),
    Stock("TSMC", "TSM", "Halbleiterproduktion", 188.90, 1.92),
    Stock("ASML", "ASML", "Halbleiterproduktion", 742.50, -0.65),
    Stock("Applied Materials", "AMAT", "Halbleiterproduktion", 204.10, 1.18),
    Stock("Micron", "MU", "Speicher und Datenträger", 112.30, 4.05),
    Stock("Seagate", "STX", "Speicher und Datenträger", 101.60, 0.95)
)
