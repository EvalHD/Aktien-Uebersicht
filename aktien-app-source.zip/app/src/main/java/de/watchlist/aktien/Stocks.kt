package de.watchlist.aktien

enum class Timeframe(val label: String) {
    D1("1T"),
    W1("1W"),
    M1("1M"),
    Y1("1J"),
    DATE("(Datum)")
}

data class Candle(val open: Float, val high: Float, val low: Float, val close: Float)

data class Stock(
    val name: String,
    val ticker: String,
    val sector: String,
    val basePrice: Double = 170.0,
    val change1D: Double = 2.45,
    val candles1D: List<Candle> = emptyList(),
    val candles1W: List<Candle> = emptyList(),
    val candles1M: List<Candle> = emptyList(),
    val candles1Y: List<Candle> = emptyList()
) {
    fun getCandles(tf: Timeframe): List<Candle> {
        val list = when (tf) {
            Timeframe.D1 -> candles1D
            Timeframe.W1 -> candles1W
            Timeframe.M1 -> candles1M
            Timeframe.Y1, Timeframe.DATE -> candles1Y
        }
        if (list.isNotEmpty()) return list
        // Fallback simulation wenn noch nicht geladen
        return generateFallbackCandles(34)
    }

    fun changeFor(tf: Timeframe): Double {
        val candles = getCandles(tf)
        if (candles.size < 2) return change1D
        val first = candles.first().open
        val last = candles.last().close
        if (first <= 0f) return change1D
        val pct = ((last - first) / first) * 100.0
        return kotlin.math.round(pct * 100.0) / 100.0
    }

    private fun generateFallbackCandles(count: Int): List<Candle> {
        val list = mutableListOf<Candle>()
        var current = basePrice * 0.95
        val vol = basePrice * 0.01
        for (i in 0 until count) {
            val open = current
            val close = open + (kotlin.math.sin(i * 0.4) * vol)
            val high = kotlin.math.max(open, close) + vol * 0.5
            val low = kotlin.math.min(open, close) - vol * 0.5
            list.add(Candle(open.toFloat(), high.toFloat(), low.toFloat(), close.toFloat()))
            current = close
        }
        return list
    }
}

val initialStocks = listOf(
    Stock("NVIDIA", "NVDA", "KI & Halbleiter", 170.0, 1.87),
    Stock("Microsoft", "MSFT", "Cloud & Software", 300.0, 0.55),
    Stock("TSMC", "TSM", "Halbleiterproduktion", 250.0, -1.15),
    Stock("AMD", "AMD", "KI & Prozessoren", 156.0, 1.45),
    Stock("Broadcom", "AVGO", "Netzwerk & KI", 178.0, 2.10)
)
