package de.watchlist.aktien

data class Stock(val name: String, val ticker: String, val sector: String)

val initialStocks = listOf(
    Stock("NVIDIA", "NVDA", "KI und Prozessoren"), Stock("AMD", "AMD", "KI und Prozessoren"), Stock("Broadcom", "AVGO", "KI und Prozessoren"),
    Stock("TSMC", "TSM", "Halbleiterproduktion"), Stock("ASML", "ASML", "Halbleiterproduktion"), Stock("Applied Materials", "AMAT", "Halbleiterproduktion"),
    Stock("Micron", "MU", "Speicher und Datenträger"), Stock("Seagate", "STX", "Speicher und Datenträger"), Stock("Western Digital", "WDC", "Speicher und Datenträger"),
    Stock("Universal Display", "OLED", "Displays und Displaymaterialien"), Stock("Corning", "GLW", "Displays und Displaymaterialien"), Stock("LG Display", "034220.KS", "Displays und Displaymaterialien"),
    Stock("NextEra Energy", "NEE", "Erneuerbare Energien"), Stock("Brookfield Renewable", "BEP", "Erneuerbare Energien"), Stock("Ørsted", "ORSTED.CO", "Erneuerbare Energien"),
    Stock("Cameco", "CCJ", "Energie- und Nukleartechnik"), Stock("GE Vernova", "GEV", "Energie- und Nukleartechnik"), Stock("Siemens Energy", "ENR.DE", "Energie- und Nukleartechnik"),
    Stock("Tesla", "TSLA", "Elektromobilität und Batterien"), Stock("BYD", "1211.HK", "Elektromobilität und Batterien"), Stock("CATL", "300750.SZ", "Elektromobilität und Batterien"),
    Stock("Toyota", "TM", "Automobiltechnik"), Stock("Hyundai Motor", "005380.KS", "Automobiltechnik"), Stock("Continental", "CON.DE", "Automobiltechnik"),
    Stock("ABB", "ABBN.SW", "Robotik und Automatisierung"), Stock("Keyence", "6861.T", "Robotik und Automatisierung"), Stock("Fanuc", "6954.T", "Robotik und Automatisierung"),
    Stock("Microsoft", "MSFT", "Cloud und Rechenzentren"), Stock("Amazon", "AMZN", "Cloud und Rechenzentren"), Stock("Equinix", "EQIX", "Cloud und Rechenzentren"),
    Stock("Arista Networks", "ANET", "Netzwerktechnik"), Stock("Cisco", "CSCO", "Netzwerktechnik"), Stock("Amphenol", "APH", "Netzwerktechnik"),
    Stock("CrowdStrike", "CRWD", "Cybersicherheit"), Stock("Palo Alto Networks", "PANW", "Cybersicherheit"), Stock("Fortinet", "FTNT", "Cybersicherheit"),
    Stock("Intuitive Surgical", "ISRG", "Medizintechnik"), Stock("Medtronic", "MDT", "Medizintechnik"), Stock("Siemens Healthineers", "SHL.DE", "Medizintechnik"),
    Stock("CRISPR Therapeutics", "CRSP", "Biotechnologie"), Stock("Vertex Pharmaceuticals", "VRTX", "Biotechnologie"), Stock("Regeneron", "REGN", "Biotechnologie"),
    Stock("Airbus", "AIR.PA", "Luft- und Raumfahrt"), Stock("RTX", "RTX", "Luft- und Raumfahrt"), Stock("Rocket Lab", "RKLB", "Luft- und Raumfahrt"),
    Stock("Linde", "LIN", "Rohstoffe und Bergbau"), Stock("Rio Tinto", "RIO", "Rohstoffe und Bergbau"), Stock("Albemarle", "ALB", "Rohstoffe und Bergbau"),
    Stock("Xylem", "XYL", "Wasser und Umwelttechnik"), Stock("Ecolab", "ECL", "Wasser und Umwelttechnik"), Stock("Veolia", "VIE.PA", "Wasser und Umwelttechnik"),
    Stock("Schneider Electric", "SU.PA", "Industrie und Energieeffizienz"), Stock("Eaton", "ETN", "Industrie und Energieeffizienz"), Stock("Honeywell", "HON", "Industrie und Energieeffizienz")
)
