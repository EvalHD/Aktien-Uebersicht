package de.watchlist.aktien

import android.content.Context
import android.graphics.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object WatchlistStore {
    private const val PREFS = "watchlist"
    private const val KEY_STOCKS = "stocks_v7"
    private const val KEY_TF = "selected_timeframe"
    private const val KEY_CUSTOM_DATE = "custom_date_label"

    fun load(context: Context): List<Stock> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_STOCKS, null)
            ?: return initialStocks
        val parsed = raw.lines().mapNotNull { line ->
            val p = line.split("|")
            if (p.size >= 5) {
                Stock(
                    name = p[0],
                    ticker = p[1],
                    sector = p[2],
                    basePrice = p[3].toDoubleOrNull() ?: 170.0,
                    change1D = p[4].toDoubleOrNull() ?: 1.5
                )
            } else null
        }
        return if (parsed.isEmpty()) initialStocks else parsed
    }

    fun save(context: Context, stocks: List<Stock>) {
        val safe = if (stocks.isEmpty()) initialStocks else stocks
        val raw = safe.joinToString("\n") {
            "${it.name}|${it.ticker}|${it.sector}|${it.basePrice}|${it.change1D}"
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_STOCKS, raw)
            .apply()
    }

    fun getTimeframe(context: Context): Timeframe {
        val name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TF, Timeframe.Y1.name) ?: Timeframe.Y1.name
        return try {
            Timeframe.valueOf(name)
        } catch (_: Exception) {
            Timeframe.Y1
        }
    }

    fun setTimeframe(context: Context, tf: Timeframe) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TF, tf.name)
            .apply()
    }

    fun getCustomDateLabel(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_CUSTOM_DATE, "(Datum)") ?: "(Datum)"
    }

    fun setCustomDateLabel(context: Context, label: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_CUSTOM_DATE, label.ifBlank { "(Datum)" })
            .apply()
    }

    fun promoteStockToTop(context: Context, index: Int) {
        val current = load(context).toMutableList()
        if (index in current.indices && index != 0) {
            val chosen = current.removeAt(index)
            current.add(0, chosen)
            save(context, current)
        }
    }

    fun cycleNextStock(context: Context) {
        val current = load(context).toMutableList()
        if (current.size > 1) {
            val first = current.removeAt(0)
            current.add(first)
            save(context, current)
        }
    }

    // Holt echte Live-Aktienkurse & Kerzen von der Yahoo Finance API für alle Watchlist-Aktien
    suspend fun fetchRealStockData(context: Context) {
        withContext(Dispatchers.IO) {
            val stocks = load(context)
            val updatedStocks = stocks.map { stock ->
                try {
                    val ticker = stock.ticker.trim()
                    // Yahoo Finance Chart API für 1 Tag, 1 Woche, 1 Monat, 1 Jahr
                    val c1D = fetchYahooChart(ticker, "1d", "5m")
                    val c1W = fetchYahooChart(ticker, "5d", "30m")
                    val c1M = fetchYahooChart(ticker, "1mo", "1d")
                    val c1Y = fetchYahooChart(ticker, "1y", "1d")

                    val latestPrice = c1Y.lastOrNull()?.close?.toDouble()
                        ?: c1D.lastOrNull()?.close?.toDouble()
                        ?: stock.basePrice

                    val prevClose = c1D.firstOrNull()?.open?.toDouble() ?: latestPrice
                    val changePct = if (prevClose > 0) ((latestPrice - prevClose) / prevClose) * 100.0 else stock.change1D

                    Stock(
                        name = stock.name,
                        ticker = stock.ticker,
                        sector = stock.sector,
                        basePrice = latestPrice,
                        change1D = changePct,
                        candles1D = c1D,
                        candles1W = c1W,
                        candles1M = c1M,
                        candles1Y = c1Y
                    )
                } catch (e: Exception) {
                    stock
                }
            }
            save(context, updatedStocks)
        }
    }

    private fun fetchYahooChart(ticker: String, range: String, interval: String): List<Candle> {
        val urlStr = "https://query1.finance.yahoo.com/v8/finance/chart/$ticker?range=$range&interval=$interval"
        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 4000
        conn.readTimeout = 4000
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        
        val reader = BufferedReader(InputStreamReader(conn.inputStream))
        val sb = StringBuilder()
        var line: String?
        while (reader.readLine().also { line = it } != null) {
            sb.append(line)
        }
        reader.close()

        val json = JSONObject(sb.toString())
        val chart = json.getJSONObject("chart")
        val result = chart.getJSONArray("result").getJSONObject(0)
        val timestamps = result.getJSONArray("timestamp")
        val quote = result.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
        val opens = quote.getJSONArray("open")
        val highs = quote.getJSONArray("high")
        val lows = quote.getJSONArray("low")
        val closes = quote.getJSONArray("close")

        val candles = mutableListOf<Candle>()
        for (i in 0 until timestamps.length()) {
            if (opens.isNull(i) || highs.isNull(i) || lows.isNull(i) || closes.isNull(i)) continue
            val o = opens.getDouble(i).toFloat()
            val h = highs.getDouble(i).toFloat()
            val l = lows.getDouble(i).toFloat()
            val c = closes.getDouble(i).toFloat()
            if (o > 0f && h > 0f && l > 0f && c > 0f) {
                candles.add(Candle(o, h, l, c))
            }
        }
        return candles
    }

    private fun formatPriceDollar(price: Double): String {
        return if (price == price.toLong().toDouble()) {
            String.format(Locale.US, "%d$", price.toLong())
        } else {
            String.format(Locale.US, "%.0f$", price)
        }
    }

    fun renderWidgetBitmap(context: Context): Bitmap {
        val stocks = load(context)
        val tf = getTimeframe(context)
        val dateLabel = getCustomDateLabel(context)

        val mainStock = stocks.first()
        val row1Stock = stocks.getOrNull(1)
        val row2Stock = stocks.getOrNull(2)

        val w = 820
        val h = 760
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val cardRect = RectF(8f, 8f, w - 8f, h - 8f)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#3D3D3D")
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(cardRect, 76f, 76f, bgPaint)

        val padX = 48f

        val tickerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#EAEAEA")
            textSize = 34f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        canvas.drawText(mainStock.ticker, padX, 78f, tickerPaint)

        val mainPct = mainStock.changeFor(tf)
        val topPctColor = if (mainPct >= 0) Color.parseColor("#E0533C") else Color.parseColor("#57B869")
        val pctPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = topPctColor
            textSize = 33f
            textAlign = Paint.Align.RIGHT
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        val arrowSymbol = if (mainPct >= 0) "↑ " else "↓ "
        val pctText = String.format(Locale.US, "%s%.2f%%", arrowSymbol, kotlin.math.abs(mainPct))
        canvas.drawText(pctText, w - padX, 78f, pctPaint)

        val chartLeft = padX + 4f
        val chartRight = w - padX - 4f
        val chartTop = 108f
        val chartBottom = 382f

        val candles = mainStock.getCandles(tf)
        var minP = Float.MAX_VALUE
        var maxP = Float.MIN_VALUE
        for (c in candles) {
            minP = min(minP, c.low)
            maxP = max(maxP, c.high)
        }
        val range = max(1f, maxP - minP)
        minP -= range * 0.08f
        maxP += range * 0.14f

        val stepX = (chartRight - chartLeft) / max(1, candles.size)
        val greenCandle = Color.parseColor("#57B869")
        val redCandle = Color.parseColor("#E04F44")

        val wickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = 3f
            style = Paint.Style.STROKE
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }

        fun priceToY(p: Float): Float {
            return chartBottom - ((p - minP) / (maxP - minP)) * (chartBottom - chartTop)
        }

        for (i in candles.indices) {
            val c = candles[i]
            val cx = chartLeft + (i + 0.5f) * stepX
            val highY = priceToY(c.high)
            val lowY = priceToY(c.low)
            val openY = priceToY(c.open)
            val closeY = priceToY(c.close)

            val up = c.close >= c.open
            val col = if (up) greenCandle else redCandle
            wickPaint.color = col
            bodyPaint.color = col

            canvas.drawLine(cx, highY, cx, lowY, wickPaint)
            val topB = min(openY, closeY)
            val botB = max(openY, closeY)
            val bH = max(6f, botB - topB)
            canvas.drawRoundRect(
                cx - stepX * 0.28f,
                topB,
                cx + stepX * 0.28f,
                topB + bH,
                2f,
                2f,
                bodyPaint
            )
        }

        if (candles.isNotEmpty()) {
            val startX = chartLeft + stepX * 1.5f
            val startY = priceToY(candles.first().low) - 22f
            val peakIdx = (candles.size * 0.44f).toInt().coerceIn(4, candles.size - 6)
            val mid1X = chartLeft + (peakIdx + 0.5f) * stepX
            val mid1Y = priceToY(candles[peakIdx].high) - 26f
            val endX = chartRight - stepX * 2.2f
            val endY = chartTop + 12f

            val trendPath = Path().apply {
                moveTo(startX, startY)
                lineTo(mid1X, mid1Y)
                lineTo(endX, endY)
            }
            val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E04F44")
                strokeWidth = 3.5f
                style = Paint.Style.STROKE
                pathEffect = DashPathEffect(floatArrayOf(11f, 8f), 0f)
            }
            canvas.drawPath(trendPath, dashPaint)

            val angle = atan2((endY - mid1Y).toDouble(), (endX - mid1X).toDouble())
            val arrowLen = 18f
            val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E04F44")
                strokeWidth = 3.8f
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
            }
            val ax1 = endX - arrowLen * cos(angle - 0.55).toFloat()
            val ay1 = endY - arrowLen * sin(angle - 0.55).toFloat()
            val ax2 = endX - arrowLen * cos(angle + 0.55).toFloat()
            val ay2 = endY - arrowLen * sin(angle + 0.55).toFloat()
            canvas.drawLine(endX, endY, ax1, ay1, arrowPaint)
            canvas.drawLine(endX, endY, ax2, ay2, arrowPaint)
        }

        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#9E9E9E")
            strokeWidth = 2.2f
        }

        val rowTfY = 442f
        val tfItems = listOf(
            Timeframe.D1 to "1T",
            Timeframe.W1 to "1W",
            Timeframe.M1 to "1M",
            Timeframe.Y1 to "1J",
            Timeframe.DATE to dateLabel
        )
        var curX = padX
        for ((itemTf, label) in tfItems) {
            val selected = (itemTf == tf)
            val tfPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (selected) Color.WHITE else Color.parseColor("#CFCFCF")
                textSize = 31f
                typeface = Typeface.create(
                    Typeface.SANS_SERIF,
                    if (selected) Typeface.BOLD else Typeface.NORMAL
                )
            }
            canvas.drawText(label, curX, rowTfY, tfPaint)
            val textW = tfPaint.measureText(label)
            if (selected) {
                val underPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    strokeWidth = 3f
                }
                canvas.drawLine(curX, rowTfY + 8f, curX + textW, rowTfY + 8f, underPaint)
            }
            curX += textW + 24f
        }

        val mainPricePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (mainPct >= 0) Color.parseColor("#E0533C") else Color.parseColor("#57B869")
            textSize = 32f
            textAlign = Paint.Align.RIGHT
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        canvas.drawText(formatPriceDollar(mainStock.basePrice), w - padX, rowTfY, mainPricePaint)

        val line1Y = 468f
        canvas.drawLine(padX, line1Y, w - padX, line1Y, dividerPaint)

        val row1Y = 532f
        if (row1Stock != null) {
            canvas.drawText(row1Stock.ticker, padX, row1Y, tickerPaint)
            val r1Pct = row1Stock.changeFor(tf)
            val r1Color = if (r1Pct >= 0) Color.parseColor("#57B869") else Color.parseColor("#E0533C")
            val r1Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = r1Color
                textSize = 32f
                textAlign = Paint.Align.RIGHT
            }
            val pctFormatted = String.format(Locale.US, "%.0f%% %s", kotlin.math.abs(r1Pct), formatPriceDollar(row1Stock.basePrice))
            canvas.drawText(pctFormatted, w - padX, row1Y, r1Paint)
        }

        val line2Y = 558f
        canvas.drawLine(padX, line2Y, w - padX, line2Y, dividerPaint)

        val row2Y = 622f
        if (row2Stock != null) {
            canvas.drawText(row2Stock.ticker, padX, row2Y, tickerPaint)
            val r2Pct = row2Stock.changeFor(tf)
            val r2Color = if (r2Pct >= 0) Color.parseColor("#57B869") else Color.parseColor("#E0533C")
            val r2Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = r2Color
                textSize = 32f
                textAlign = Paint.Align.RIGHT
            }
            val pctFormatted2 = String.format(Locale.US, "%.0f%% %s", kotlin.math.abs(r2Pct), formatPriceDollar(row2Stock.basePrice))
            canvas.drawText(pctFormatted2, w - padX, row2Y, r2Paint)
        }

        val line3Y = 648f
        canvas.drawLine(padX, line3Y, w - padX, line3Y, dividerPaint)

        val settingsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E0E0E0")
            textSize = 31f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        canvas.drawText("settings...", padX, 710f, settingsPaint)

        return bmp
    }
}
