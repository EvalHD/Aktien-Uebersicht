package de.watchlist.aktien

import android.content.Context
import android.graphics.*
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

object WatchlistStore {
    private const val PREFS = "watchlist"
    private const val KEY = "stocks_v3"
    private const val KEY_INDEX = "current_stock_idx"

    fun load(context: Context): List<Stock> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return initialStocks
        val parsed = raw.lines().mapNotNull { line ->
            val p = line.split("|")
            when {
                p.size >= 5 -> Stock(
                    p[0],
                    p[1],
                    p[2],
                    p[3].toDoubleOrNull() ?: 150.0,
                    p[4].toDoubleOrNull() ?: 1.5
                )
                p.size == 3 -> Stock(p[0], p[1], p[2], 165.0, 1.8)
                else -> null
            }
        }
        return if (parsed.isEmpty()) initialStocks else parsed
    }

    fun save(context: Context, stocks: List<Stock>) {
        val safeList = if (stocks.isEmpty()) initialStocks else stocks
        val raw = safeList.joinToString("\n") {
            "${it.name}|${it.ticker}|${it.sector}|${it.basePrice}|${it.changePct}"
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, raw)
            .apply()
    }

    fun getCurrentIndex(context: Context, size: Int): Int {
        if (size <= 0) return 0
        val idx = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_INDEX, 0)
        return idx.mod(size)
    }

    fun setCurrentIndex(context: Context, index: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_INDEX, index)
            .apply()
    }

    fun nextStock(context: Context): Stock {
        val list = load(context)
        val nextIdx = (getCurrentIndex(context, list.size) + 1).mod(list.size)
        setCurrentIndex(context, nextIdx)
        return list[nextIdx]
    }

    fun getCurrentStock(context: Context): Pair<Stock, String> {
        val list = load(context)
        val idx = getCurrentIndex(context, list.size)
        return Pair(list[idx], "${idx + 1}/${list.size}")
    }

    // Zeichnet den blauen Aktien-Bogen exakt im Stil von Bild 2 + Wechsel-Button unten
    fun renderArcWidgetBitmap(context: Context): Bitmap {
        val (stock, positionLabel) = getCurrentStock(context)
        val w = 1100
        val h = 620
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val domeLeft = 26f
        val domeRight = w - 26f
        val domeTop = 18f
        val domeBottom = 520f

        // Bogen-Kuppel-Pfad wie in Bild 2
        val domePath = Path().apply {
            moveTo(domeLeft, domeBottom)
            lineTo(domeLeft, 360f)
            cubicTo(domeLeft, domeTop, domeRight, domeTop, domeRight, 360f)
            lineTo(domeRight, domeBottom)
            close()
        }

        // Tiefblauer bis schwarzer Hintergrund im Bogen
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(
                0f, domeTop, 0f, domeBottom,
                Color.parseColor("#081B33"),
                Color.parseColor("#030811"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawPath(domePath, bgPaint)

        canvas.save()
        canvas.clipPath(domePath)

        val chartLeft = 58f
        val chartRight = w - 135f
        val chartTop = 155f
        val chartBottom = domeBottom - 44f

        val candles = stock.generateCandles(64)
        var minPrice = Float.MAX_VALUE
        var maxPrice = Float.MIN_VALUE
        for (c in candles) {
            minPrice = min(minPrice, c.low)
            maxPrice = max(maxPrice, c.high)
        }
        val pad = (maxPrice - minPrice) * 0.12f
        minPrice -= pad
        maxPrice += pad

        // Feines blaues Raster (Grid)
        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#133154")
            strokeWidth = 1.5f
            style = Paint.Style.STROKE
        }
        val axisTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#8AB4F8")
            textSize = 21f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }

        // Horizontale Rasterlinien + Preisachse rechts (wie 198.00, 196.00 ... in Bild 2)
        val rows = 7
        for (i in 0..rows) {
            val y = chartTop + i * ((chartBottom - chartTop) / rows)
            canvas.drawLine(chartLeft, y, chartRight, y, gridPaint)
            val pVal = maxPrice - i * ((maxPrice - minPrice) / rows)
            if (i in 1 until rows) {
                canvas.drawText(
                    String.format(Locale.US, "%.2f", pVal),
                    chartRight + 14f,
                    y + 7f,
                    axisTextPaint
                )
            }
        }

        // Vertikale Rasterlinien + Zeitachse unten (09:00 bis 17:00 wie in Bild 2)
        val times = listOf("09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00")
        for (i in times.indices) {
            val x = chartLeft + i * ((chartRight - chartLeft) / (times.size - 1))
            canvas.drawLine(x, domeTop + 30f, x, chartBottom, gridPaint)
            canvas.drawText(times[i], x - 26f, domeBottom - 12f, axisTextPaint)
        }

        // Untere Achsenlinie & rechte Achsenlinie
        val axisBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2A5282")
            strokeWidth = 2f
        }
        canvas.drawLine(chartLeft, chartBottom, chartRight, chartBottom, axisBorderPaint)
        canvas.drawLine(chartRight, domeTop + 40f, chartRight, chartBottom, axisBorderPaint)

        // Blauer Farbverlauf unter der Kurve + Blaue Candlesticks
        val stepX = (chartRight - chartLeft) / candles.size
        val linePath = Path()
        val areaPath = Path()

        for (i in candles.indices) {
            val c = candles[i]
            val cx = chartLeft + (i + 0.5f) * stepX
            val closeY = chartBottom - ((c.close - minPrice) / (maxPrice - minPrice)) * (chartBottom - chartTop)
            if (i == 0) {
                linePath.moveTo(cx, closeY)
                areaPath.moveTo(cx, chartBottom)
                areaPath.lineTo(cx, closeY)
            } else {
                linePath.lineTo(cx, closeY)
                areaPath.lineTo(cx, closeY)
            }
        }
        val lastX = chartLeft + (candles.size - 0.5f) * stepX
        areaPath.lineTo(lastX, chartBottom)
        areaPath.close()

        val areaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(
                0f, chartTop, 0f, chartBottom,
                Color.parseColor("#660091EA"),
                Color.parseColor("#050091EA"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawPath(areaPath, areaPaint)

        // Blaue Kerzen (Hell-Cyan-Blau für steigende Kerzen, Tief-Kobaltblau für fallende Kerzen)
        val wickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = 2.2f
            style = Paint.Style.STROKE
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }

        for (i in candles.indices) {
            val c = candles[i]
            val cx = chartLeft + (i + 0.5f) * stepX
            val highY = chartBottom - ((c.high - minPrice) / (maxPrice - minPrice)) * (chartBottom - chartTop)
            val lowY = chartBottom - ((c.low - minPrice) / (maxPrice - minPrice)) * (chartBottom - chartTop)
            val openY = chartBottom - ((c.open - minPrice) / (maxPrice - minPrice)) * (chartBottom - chartTop)
            val closeY = chartBottom - ((c.close - minPrice) / (maxPrice - minPrice)) * (chartBottom - chartTop)

            val isUp = c.close >= c.open
            val color = if (isUp) Color.parseColor("#00E5FF") else Color.parseColor("#1E88E5")
            wickPaint.color = color
            bodyPaint.color = color

            canvas.drawLine(cx, highY, cx, lowY, wickPaint)
            val topBody = min(openY, closeY)
            val botBody = max(openY, closeY)
            val bodyHeight = max(4f, botBody - topBody)
            canvas.drawRoundRect(
                cx - stepX * 0.34f,
                topBody,
                cx + stepX * 0.34f,
                topBody + bodyHeight,
                2f,
                2f,
                bodyPaint
            )
        }

        // Leuchtend blaue Verbindungslinie
        val glowLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#40C4FF")
            strokeWidth = 3.2f
            style = Paint.Style.STROKE
        }
        canvas.drawPath(linePath, glowLinePaint)

        // Aktientitel & Infos oben im Bogen
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 32f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        canvas.drawText("${stock.name} (${stock.ticker})", w / 2f, 102f, titlePaint)

        val sign = if (stock.changePct >= 0) "+" else ""
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00E5FF")
            textSize = 23f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        canvas.drawText(
            String.format(Locale.US, "%.2f USD  •  %s%.2f%%  •  Watchlist %s", stock.basePrice, sign, stock.changePct, positionLabel),
            w / 2f,
            136f,
            subPaint
        )

        canvas.restore()

        // Blauer 3D-Glas-Rahmen um den gesamten Bogen (wie in Bild 2, aber in Blau)
        val outerRim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0D47A1")
            strokeWidth = 14f
            style = Paint.Style.STROKE
        }
        canvas.drawPath(domePath, outerRim)

        val midRim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2979FF")
            strokeWidth = 6f
            style = Paint.Style.STROKE
        }
        canvas.drawPath(domePath, midRim)

        val innerHighlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#80D8FF")
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }
        canvas.drawPath(domePath, innerHighlight)

        // Blauer Button unten zum Wechseln der Watchlist-Aktien
        val btnRect = RectF(w / 2f - 230f, 536f, w / 2f + 230f, 608f)
        val btnFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(
                btnRect.left, btnRect.top, btnRect.right, btnRect.bottom,
                Color.parseColor("#0052CC"),
                Color.parseColor("#0091EA"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRoundRect(btnRect, 36f, 36f, btnFill)

        val btnBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#80D8FF")
            strokeWidth = 3f
            style = Paint.Style.STROKE
        }
        canvas.drawRoundRect(btnRect, 36f, 36f, btnBorder)

        val btnText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 25f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        canvas.drawText("⟳ Aktie tauschen (${stock.ticker})", w / 2f, 581f, btnText)

        return bmp
    }
}
