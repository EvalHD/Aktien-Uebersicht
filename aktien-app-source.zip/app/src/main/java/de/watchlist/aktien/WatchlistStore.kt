package de.watchlist.aktien

import android.content.Context

// Speichert die Watchlist dauerhaft auf dem Gerät. App und Widget lesen dieselben Daten.
object WatchlistStore {
    private const val PREFS = "watchlist"
    private const val KEY = "stocks"

    fun load(context: Context): List<Stock> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return initialStocks
        return raw.lines().mapNotNull { line ->
            val p = line.split("|")
            if (p.size == 3) Stock(p[0], p[1], p[2]) else null
        }
    }

    fun save(context: Context, stocks: List<Stock>) {
        val raw = stocks.joinToString("\n") { "${it.name}|${it.ticker}|${it.sector}" }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, raw).apply()
    }
}
