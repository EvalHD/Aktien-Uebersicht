package de.watchlist.aktien

import android.content.Context
import android.graphics.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object WatchlistStore {
    private const val PREFS = "watchlist"
    private const val KEY_STOCKS = "stocks_v7"
    private const val KEY_TF = "selected_timeframe"
    private const val KEY_CUSTOM_DATE = "custom_date_label"
    private const val KEY_CACHE = "market_cache_v1"
    private const val KEY_LAST_OK = "last_refresh_ok"
    private const val KEY_LAST_TRY = "last_refresh_try"

    fun load(context: Context): List<Stock> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_STOCKS, null)
        val base = if (raw == null) initialStocks else parseStocks(raw)
        val cache = readCache(context)
        return base.map { applyCache(it, cache) }
    }

    private fun parseStocks(raw: String): List<Stock> {
        val parsed = raw.lines().mapNotNull { line ->
            val p = line.split("|")
            if (p.size >= 5) {
                Stock(
                    name = p[0],
                    ticker = p[1],
                    sector = p[2],
                    basePrice = p[3].toDoubleOrNull() ?: 170.0,
                    change1D = p[4].toDoubleOrNull() ?: 1.5
                )
            } else null
        }
        return if (parsed.isEmpty()) initialStocks else parsed
    }

    fun save(context: Context, stocks: List<Stock>) {
        val safe = if (stocks.isEmpty()) initialStocks else stocks
        val raw = safe.joinToString("\n") {
            "${it.name}|${it.ticker}|${it.sector}|${it.basePrice}|${it.change1D}"
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_STOCKS, raw)
            .apply()
    }

    fun getTimeframe(context: Context): Timeframe {
        val name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TF, Timeframe.Y1.name) ?: Timeframe.Y1.name
        return try {
            Timeframe.valueOf(name)
        } catch (_: Exception) {
            Timeframe.Y1
        }
    }

    fun setTimeframe(context: Context, tf: Timeframe) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TF, tf.name)
            .apply()
    }

    fun getCustomDateLabel(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_CUSTOM_DATE, "(Datum)") ?: "(Datum)"
    }

    fun setCustomDateLabel(context: Context, label: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_CUSTOM_DATE, label.ifBlank { "(Datum)" })
            .apply()
    }

    fun promoteStockToTop(context: Context, index: Int) {
        val current = load(context).toMutableList()
        if (index in current.indices && index != 0) {
            val chosen = current.removeAt(index)
            current.add(0, chosen)
            save(context, current)
        }
    }

    fun cycleNextStock(context: Context) {
        val current = load(context).toMutableList()
        if (current.size > 1) {
            val first = current.removeAt(0)
            current.add(first)
            save(context, current)
        }
    }

    // ---------- Marktdaten-Cache (Kerzen werden dauerhaft gespeichert) ----------

    private fun r2(x: Float): Double = Math.round(x * 100.0) / 100.0

    private fun candlesToJson(list: List<Candle>): JSONArray {
        val arr = JSONArray()
        for (c in list) {
            arr.put(JSONArray().put(r2(c.open)).put(r2(c.high)).put(r2(c.low)).put(r2(c.close)))
        }
        return arr
    }

    private fun jsonToCandles(arr: JSONArray?): List<Candle> {
        if (arr == null) return emptyList()
        val out = ArrayList<Candle>(arr.length())
        for (i in 0 until arr.length()) {
            val c = arr.optJSONArray(i) ?: continue
            if (c.length() < 4) continue
            out.add(Candle(c.getDouble(0).toFloat(), c.getDouble(1).toFloat(), c.getDouble(2).toFloat(), c.getDouble(3).toFloat()))
        }
        return out
    }

    private fun readCache(context: Context): JSONObject {
        return try {
            JSONObject(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_CACHE, null) ?: "{}")
        } catch (_: Exception) {
            JSONObject()
        }
    }

    private fun applyCache(stock: Stock, cache: JSONObject): Stock {
        val e = cache.optJSONObject(stock.ticker.trim().uppercase(Locale.US)) ?: return stock
        return stock.copy(
            basePrice = e.optDouble("price", stock.basePrice),
            change1D = e.optDouble("chg", stock.change1D),
            candles1D = jsonToCandles(e.optJSONArray("d1")),
            candles1W = jsonToCandles(e.optJSONArray("w1")),
            candles1M = jsonToCandles(e.optJSONArray("m1")),
            candles1Y = jsonToCandles(e.optJSONArray("y1"))
        )
    }

    private class ChartData(val candles: List<Candle>, val price: Double?, val prevClose: Double?)

    /** true, wenn die Daten älter als maxAgeMs sind (und der letzte Versuch länger als 60 s her ist). */
    fun shouldRefresh(context: Context, maxAgeMs: Long): Boolean {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - p.getLong(KEY_LAST_TRY, 0L) < 60_000L) return false
        return now - p.getLong(KEY_LAST_OK, 0L) > maxAgeMs
    }

    // Holt echte Live-Kurse und Kerzen von Yahoo Finance (blockierend, parallel pro Aktie/Zeitraum).
    // Gibt true zurück, wenn mindestens ein Abruf geklappt hat.
    fun fetchBlocking(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putLong(KEY_LAST_TRY, System.currentTimeMillis()).apply()

        val tickers = load(context).map { it.ticker.trim().uppercase(Locale.US) }.filter { it.isNotEmpty() }.distinct()
        if (tickers.isEmpty()) return false

        val ranges = listOf(
            Triple("d1", "1d", "5m"),
            Triple("w1", "5d", "30m"),
            Triple("m1", "1mo", "1d"),
            Triple("y1", "1y", "1d")
        )
        val pool = Executors.newFixedThreadPool(16)
        val cache = readCache(context)
        var anyOk = false
        try {
            val jobs = tickers.associateWith { ticker ->
                ranges.map { (key, range, interval) ->
                    key to pool.submit(Callable<ChartData?> {
                        try { fetchYahooChart(ticker, range, interval) } catch (_: Exception) { null }
                    })
                }
            }
            val deadline = System.currentTimeMillis() + 9_000L
            for ((ticker, list) in jobs) {
                val entry = cache.optJSONObject(ticker) ?: JSONObject()
                var ok = false
                for ((key, future) in list) {
                    val wait = (deadline - System.currentTimeMillis()).coerceAtLeast(100L)
                    val data = try { future.get(wait, TimeUnit.MILLISECONDS) } catch (_: Exception) { null }
                    if (data == null || data.candles.isEmpty()) continue
                    entry.put(key, candlesToJson(data.candles))
                    ok = true
                    if (key == "d1") {
                        val price = data.price ?: data.candles.last().close.toDouble()
                        val prev = data.prevClose ?: data.candles.first().open.toDouble()
                        entry.put("price", price)
                        if (prev > 0) entry.put("chg", ((price - prev) / prev) * 100.0)
                    }
                }
                if (ok) {
                    if (!entry.has("price")) {
                        val y = jsonToCandles(entry.optJSONArray("y1"))
                        if (y.isNotEmpty()) entry.put("price", y.last().close.toDouble())
                    }
                    cache.put(ticker, entry)
                    anyOk = true
                }
            }
        } finally {
            pool.shutdownNow()
        }
        if (anyOk) {
            prefs.edit()
                .putString(KEY_CACHE, cache.toString())
                .putLong(KEY_LAST_OK, System.currentTimeMillis())
                .apply()
        }
        return anyOk
    }

    suspend fun fetchRealStockData(context: Context) {
        withContext(Dispatchers.IO) { fetchBlocking(context) }
    }

    private fun fetchYahooChart(ticker: String, range: String, interval: String): ChartData {
        val enc = URLEncoder.encode(ticker, "UTF-8")
        val url = URL("https://query1.finance.yahoo.com/v8/finance/chart/$enc?range=$range&interval=$interval")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
            )
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode != 200) throw RuntimeException("HTTP ${conn.responseCode}")
            val text = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }

            val result = JSONObject(text).getJSONObject("chart").getJSONArray("result").getJSONObject(0)
            val meta = result.optJSONObject("meta")
            val price = meta?.optDouble("regularMarketPrice", Double.NaN)?.takeIf { !it.isNaN() && it > 0 }
            val prev = (meta?.optDouble("chartPreviousClose", Double.NaN)?.takeIf { !it.isNaN() && it > 0 })
                ?: (meta?.optDouble("previousClose", Double.NaN)?.takeIf { !it.isNaN() && it > 0 })

            val timestamps = result.getJSONArray("timestamp")
            val quote = result.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
            val opens = quote.getJSONArray("open")
            val highs = quote.getJSONArray("high")
            val lows = quote.getJSONArray("low")
            val closes = quote.getJSONArray("close")

            val candles = mutableListOf<Candle>()
            for (i in 0 until timestamps.length()) {
                if (opens.isNull(i) || highs.isNull(i) || lows.isNull(i) || closes.isNull(i)) continue
                val o = opens.getDouble(i).toFloat()
                val h = highs.getDouble(i).toFloat()
                val l = lows.getDouble(i).toFloat()
                val c = closes.getDouble(i).toFloat()
                if (o > 0f && h > 0f && l > 0f && c > 0f) candles.add(Candle(o, h, l, c))
            }
            return ChartData(candles, price, prev)
        } finally {
            conn.disconnect()
        }
    }

    private fun formatPriceDollar(price: Double): String {
        return if (price == price.toLong().toDouble()) {
            String.format(Locale.US, "%d$", price.toLong())
        } else {
            String.format(Locale.US, "%.0f$", price)
        }
    }

    fun renderWidgetBitmap(context: Context): Bitmap {
        val stocks = load(context)
        val tf = getTimeframe(context)
        val dateLabel = getCustomDateLabel(context)

        val mainStock = stocks.first()
        val row1Stock = stocks.getOrNull(1)
        val row2Stock = stocks.getOrNull(2)

        val w = 820
        val h = 760
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val cardRect = RectF(8f, 8f, w - 8f, h - 8f)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#3D3D3D")
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(cardRect, 76f, 76f, bgPaint)

        val padX = 48f

        val tickerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#EAEAEA")
            textSize = 34f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        canvas.drawText(mainStock.ticker, padX, 78f, tickerPaint)

        val mainPct = mainStock.changeFor(tf)
        val topPctColor = if (mainPct >= 0) Color.parseColor("#E0533C") else Color.parseColor("#57B869")
        val pctPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = topPctColor
            textSize = 33f
            textAlign = Paint.Align.RIGHT
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        val arrowSymbol = if (mainPct >= 0) "↑ " else "↓ "
        val pctText = if (mainStock.hasData) String.format(Locale.US, "%s%.2f%%", arrowSymbol, kotlin.math.abs(mainPct)) else "–"
        canvas.drawText(pctText, w - padX, 78f, pctPaint)

        val chartLeft = padX + 4f
        val chartRight = w - padX - 4f
        val chartTop = 108f
        val chartBottom = 382f

        val candles = mainStock.getCandles(tf)
        var minP = Float.MAX_VALUE
        var maxP = Float.MIN_VALUE
        for (c in candles) {
            minP = min(minP, c.low)
            maxP = max(maxP, c.high)
        }
        val range = max(1f, maxP - minP)
        minP -= range * 0.08f
        maxP += range * 0.14f

        val stepX = (chartRight - chartLeft) / max(1, candles.size)
        val greenCandle = Color.parseColor("#57B869")
        val redCandle = Color.parseColor("#E04F44")

        val wickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = 3f
            style = Paint.Style.STROKE
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }

        fun priceToY(p: Float): Float {
            return chartBottom - ((p - minP) / (maxP - minP)) * (chartBottom - chartTop)
        }

        for (i in candles.indices) {
            val c = candles[i]
            val cx = chartLeft + (i + 0.5f) * stepX
            val highY = priceToY(c.high)
            val lowY = priceToY(c.low)
            val openY = priceToY(c.open)
            val closeY = priceToY(c.close)

            val up = c.close >= c.open
            val col = if (up) greenCandle else redCandle
            wickPaint.color = col
            bodyPaint.color = col

            canvas.drawLine(cx, highY, cx, lowY, wickPaint)
            val topB = min(openY, closeY)
            val botB = max(openY, closeY)
            val bH = max(6f, botB - topB)
            canvas.drawRoundRect(
                cx - stepX * 0.28f,
                topB,
                cx + stepX * 0.28f,
                topB + bH,
                2f,
                2f,
                bodyPaint
            )
        }

        if (candles.isEmpty()) {
            val msgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#CFCFCF")
                textSize = 32f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("Kurse werden geladen …", w / 2f, (chartTop + chartBottom) / 2f, msgPaint)
        } else if (candles.size >= 2) {
            // Echte Trendlinie (lineare Regression über die Schlusskurse)
            val n = candles.size
            var sx = 0.0; var sy = 0.0; var sxy = 0.0; var sxx = 0.0
            for (i in 0 until n) {
                val y = candles[i].close.toDouble()
                sx += i; sy += y; sxy += i * y; sxx += i.toDouble() * i
            }
            val denom = n * sxx - sx * sx
            val slope = if (denom != 0.0) (n * sxy - sx * sy) / denom else 0.0
            val intercept = (sy - slope * sx) / n
            val startX = chartLeft + 0.5f * stepX
            val endX = chartLeft + (n - 0.5f) * stepX
            val startY = priceToY(intercept.toFloat()).coerceIn(chartTop, chartBottom)
            val endY = priceToY((intercept + slope * (n - 1)).toFloat()).coerceIn(chartTop, chartBottom)

            val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E04F44")
                strokeWidth = 3.5f
                style = Paint.Style.STROKE
                pathEffect = DashPathEffect(floatArrayOf(11f, 8f), 0f)
            }
            canvas.drawPath(Path().apply { moveTo(startX, startY); lineTo(endX, endY) }, dashPaint)

            val angle = atan2((endY - startY).toDouble(), (endX - startX).toDouble())
            val arrowLen = 18f
            val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E04F44")
                strokeWidth = 3.8f
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
            }
            val ax1 = endX - arrowLen * cos(angle - 0.55).toFloat()
            val ay1 = endY - arrowLen * sin(angle - 0.55).toFloat()
            val ax2 = endX - arrowLen * cos(angle + 0.55).toFloat()
            val ay2 = endY - arrowLen * sin(angle + 0.55).toFloat()
            canvas.drawLine(endX, endY, ax1, ay1, arrowPaint)
            canvas.drawLine(endX, endY, ax2, ay2, arrowPaint)
        }

        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#9E9E9E")
            strokeWidth = 2.2f
        }

        val rowTfY = 442f
        val tfItems = listOf(
            Timeframe.D1 to "1T",
            Timeframe.W1 to "1W",
            Timeframe.M1 to "1M",
            Timeframe.Y1 to "1J",
            Timeframe.DATE to dateLabel
        )
        var curX = padX
        for ((itemTf, label) in tfItems) {
            val selected = (itemTf == tf)
            val tfPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (selected) Color.WHITE else Color.parseColor("#CFCFCF")
                textSize = 31f
                typeface = Typeface.create(
                    Typeface.SANS_SERIF,
                    if (selected) Typeface.BOLD else Typeface.NORMAL
                )
            }
            canvas.drawText(label, curX, rowTfY, tfPaint)
            val textW = tfPaint.measureText(label)
            if (selected) {
                val underPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    strokeWidth = 3f
                }
                canvas.drawLine(curX, rowTfY + 8f, curX + textW, rowTfY + 8f, underPaint)
            }
            curX += textW + 24f
        }

        val mainPricePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (mainPct >= 0) Color.parseColor("#E0533C") else Color.parseColor("#57B869")
            textSize = 32f
            textAlign = Paint.Align.RIGHT
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        canvas.drawText(if (mainStock.hasData) formatPriceDollar(mainStock.basePrice) else "–", w - padX, rowTfY, mainPricePaint)

        val line1Y = 468f
        canvas.drawLine(padX, line1Y, w - padX, line1Y, dividerPaint)

        val row1Y = 532f
        if (row1Stock != null) {
            canvas.drawText(row1Stock.ticker, padX, row1Y, tickerPaint)
            val r1Pct = row1Stock.changeFor(tf)
            val r1Color = if (r1Pct >= 0) Color.parseColor("#57B869") else Color.parseColor("#E0533C")
            val r1Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = r1Color
                textSize = 32f
                textAlign = Paint.Align.RIGHT
            }
            val pctFormatted = if (row1Stock.hasData) String.format(Locale.US, "%.1f%% %s", kotlin.math.abs(r1Pct), formatPriceDollar(row1Stock.basePrice)) else "–"
            canvas.drawText(pctFormatted, w - padX, row1Y, r1Paint)
        }

        val line2Y = 558f
        canvas.drawLine(padX, line2Y, w - padX, line2Y, dividerPaint)

        val row2Y = 622f
        if (row2Stock != null) {
            canvas.drawText(row2Stock.ticker, padX, row2Y, tickerPaint)
            val r2Pct = row2Stock.changeFor(tf)
            val r2Color = if (r2Pct >= 0) Color.parseColor("#57B869") else Color.parseColor("#E0533C")
            val r2Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = r2Color
                textSize = 32f
                textAlign = Paint.Align.RIGHT
            }
            val pctFormatted2 = if (row2Stock.hasData) String.format(Locale.US, "%.1f%% %s", kotlin.math.abs(r2Pct), formatPriceDollar(row2Stock.basePrice)) else "–"
            canvas.drawText(pctFormatted2, w - padX, row2Y, r2Paint)
        }

        val line3Y = 648f
        canvas.drawLine(padX, line3Y, w - padX, line3Y, dividerPaint)

        val settingsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E0E0E0")
            textSize = 31f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        canvas.drawText("settings...", padX, 710f, settingsPaint)

        return bmp
    }
}
