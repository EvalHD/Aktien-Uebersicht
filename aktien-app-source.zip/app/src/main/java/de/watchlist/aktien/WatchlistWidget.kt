package de.watchlist.aktien

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Column
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider

class WatchlistWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val stocks = WatchlistStore.load(context)
        provideContent {
            val dark = ColorProvider(Color(0xFF202124))
            val gray = ColorProvider(Color(0xFF667085))
            Column(GlanceModifier.fillMaxSize().background(Color.White).padding(12.dp)) {
                Text("Meine Watchlist", style = TextStyle(color = dark, fontWeight = FontWeight.Bold))
                Spacer(GlanceModifier.height(6.dp))
                stocks.take(8).forEach { Text("${it.name} · ${it.ticker}", style = TextStyle(color = dark)) }
                if (stocks.size > 8) {
                    Spacer(GlanceModifier.height(4.dp))
                    Text("+ ${stocks.size - 8} weitere in der App", style = TextStyle(color = gray))
                }
            }
        }
    }
}

class WatchlistWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = WatchlistWidget()
}
