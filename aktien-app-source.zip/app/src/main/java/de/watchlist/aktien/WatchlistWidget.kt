package de.watchlist.aktien

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class WatchlistWidgetReceiver : AppWidgetProvider() {

    companion object {
        const val ACTION_NEXT_STOCK = "de.watchlist.aktien.ACTION_NEXT_STOCK"

        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, WatchlistWidgetReceiver::class.java))
            for (id in ids) {
                updateWidget(context, manager, id)
            }
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, appWidgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_loading)
            val bitmap = WatchlistStore.renderArcWidgetBitmap(context)
            views.setImageViewBitmap(R.id.widget_arc_image, bitmap)

            val nextIntent = Intent(context, WatchlistWidgetReceiver::class.java).apply {
                action = ACTION_NEXT_STOCK
            }
            val pendingNext = PendingIntent.getBroadcast(
                context,
                0,
                nextIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Klick auf den unteren Button (oder den Bogen) wechselt zur nächsten Aktie der Watchlist
            views.setOnClickPendingIntent(R.id.widget_switch_button, pendingNext)
            views.setOnClickPendingIntent(R.id.widget_arc_image, pendingNext)

            manager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_NEXT_STOCK) {
            WatchlistStore.nextStock(context)
            updateAllWidgets(context)
        }
    }
}
