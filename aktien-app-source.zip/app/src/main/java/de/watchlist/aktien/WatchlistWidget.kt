package de.watchlist.aktien

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class WatchlistWidgetReceiver : AppWidgetProvider() {

    companion object {
        const val ACTION_TF_1D = "de.watchlist.aktien.ACTION_TIMEFRAME_1D"
        const val ACTION_TF_1W = "de.watchlist.aktien.ACTION_TIMEFRAME_1W"
        const val ACTION_TF_1M = "de.watchlist.aktien.ACTION_TIMEFRAME_1M"
        const val ACTION_TF_1Y = "de.watchlist.aktien.ACTION_TIMEFRAME_1Y"
        const val ACTION_TF_DATE = "de.watchlist.aktien.ACTION_TIMEFRAME_DATE"
        const val ACTION_ROW_1 = "de.watchlist.aktien.ACTION_SELECT_ROW_1"
        const val ACTION_ROW_2 = "de.watchlist.aktien.ACTION_SELECT_ROW_2"
        const val ACTION_NEXT = "de.watchlist.aktien.ACTION_NEXT_STOCK"

        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, WatchlistWidgetReceiver::class.java))
            for (id in ids) {
                updateWidget(context, manager, id)
            }
        }

        private fun broadcastPi(context: Context, action: String, reqCode: Int): PendingIntent {
            val intent = Intent(context, WatchlistWidgetReceiver::class.java).apply {
                this.action = action
            }
            return PendingIntent.getBroadcast(
                context,
                reqCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, appWidgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_loading)
            val bitmap = WatchlistStore.renderWidgetBitmap(context)
            views.setImageViewBitmap(R.id.widget_card_image, bitmap)

            views.setOnClickPendingIntent(R.id.btn_chart_area, broadcastPi(context, ACTION_NEXT, 1))
            views.setOnClickPendingIntent(R.id.btn_price_area, broadcastPi(context, ACTION_NEXT, 2))

            views.setOnClickPendingIntent(R.id.btn_tf_1d, broadcastPi(context, ACTION_TF_1D, 10))
            views.setOnClickPendingIntent(R.id.btn_tf_1w, broadcastPi(context, ACTION_TF_1W, 11))
            views.setOnClickPendingIntent(R.id.btn_tf_1m, broadcastPi(context, ACTION_TF_1M, 12))
            views.setOnClickPendingIntent(R.id.btn_tf_1y, broadcastPi(context, ACTION_TF_1Y, 13))
            views.setOnClickPendingIntent(R.id.btn_tf_date, broadcastPi(context, ACTION_TF_DATE, 14))

            views.setOnClickPendingIntent(R.id.btn_row_1, broadcastPi(context, ACTION_ROW_1, 20))
            views.setOnClickPendingIntent(R.id.btn_row_2, broadcastPi(context, ACTION_ROW_2, 21))

            val appIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val appPi = PendingIntent.getActivity(
                context,
                30,
                appIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.btn_settings, appPi)

            manager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
        // Echte Kurse im Hintergrund nachladen (mind. alle 5 Minuten)
        refreshInBackground(context)
    }

    private fun refreshInBackground(context: Context) {
        if (!WatchlistStore.shouldRefresh(context, 5 * 60 * 1000L)) return
        val pending: BroadcastReceiver.PendingResult? = goAsync()
        val appContext = context.applicationContext
        Thread {
            try {
                if (WatchlistStore.fetchBlocking(appContext)) {
                    updateAllWidgets(appContext)
                }
            } catch (_: Exception) {
            } finally {
                pending?.finish()
            }
        }.start()
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TF_1D -> WatchlistStore.setTimeframe(context, Timeframe.D1)
            ACTION_TF_1W -> WatchlistStore.setTimeframe(context, Timeframe.W1)
            ACTION_TF_1M -> WatchlistStore.setTimeframe(context, Timeframe.M1)
            ACTION_TF_1Y -> WatchlistStore.setTimeframe(context, Timeframe.Y1)
            ACTION_TF_DATE -> WatchlistStore.setTimeframe(context, Timeframe.DATE)
            ACTION_ROW_1 -> WatchlistStore.promoteStockToTop(context, 1)
            ACTION_ROW_2 -> WatchlistStore.promoteStockToTop(context, 2)
            ACTION_NEXT -> WatchlistStore.cycleNextStock(context)
            else -> return
        }
        updateAllWidgets(context)
        refreshInBackground(context)
    }
}
